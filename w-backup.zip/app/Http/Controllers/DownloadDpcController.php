<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Anggota;
use App\Models\Kabupaten;
use App\Models\Kecamatan;
use Barryvdh\DomPDF\Facade\Pdf;

class DownloadDpcController extends Controller
{
    public function index(Request $request)
    {
        $user = Auth::user();

        if (!$user) {
            return redirect()->route('login')->with('error', 'User tidak ditemukan');
        }

        // Ambil kabupaten dari kabupaten user
        $kabupaten = $user->kabupaten;
        $kabupatenId = $user->kabupaten_id;

        // Ambil kecamatan sesuai kabupaten tersebut
        $kecamatans = Kecamatan::where('kabupaten_id', $kabupatenId)->get();

        return view('downloaddpc', compact('kabupaten', 'kecamatans', 'user'));
    }
}