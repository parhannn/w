<!DOCTYPE html>
<html>

<head>
    <title>Data Anggota Himpunan Wanita Disabilitas Indonesia Lampung</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .header {
            text-align: center;
        }

        .header img {
            width: 60px;
            height: auto;
        }

        .line {
            border-top: 2px solid black;
            margin-top: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table,
        th,
        td {
            border: 1px solid black;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
        }

        .logo {
            width: 60px;
            height: 60px;
        }
    </style>
</head>

<body>
    <div class="header">
        <img class="logo" src="<?php echo e(public_path('hwdi.jpg')); ?>" />
        <h2>Data Anggota HWDI Lampung</h2>
    </div>
    <p>Kabupaten: <?php echo e($kabupaten ?? 'Semua'); ?>, Kecamatan: <?php echo e($kecamatan ?? 'Semua'); ?>, Jenis Disabilitas:
        <?php echo e($jenis_disabilitas ?? 'Semua'); ?></p>
    <div class="line"></div>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>NIK</th>
                <th>Alamat</th>
                <th>Tanggal Lahir</th>
                <th>Jenis Disabilitas</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $anggotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $anggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="border px-4 py-3"><?php echo e($index + 1); ?></td>
                    <td class="border px-4 py-3"><?php echo e($anggota->nama); ?></td>
                    <td class="border px-4 py-3"><?php echo e($anggota->nik); ?></td>
                    <td class="border px-4 py-3"><?php echo e($anggota->alamat); ?></td>
                    <td class="border px-4 py-3">
                        <?php echo e(\Carbon\Carbon::parse($anggota->tanggal_lahir)->format('d-m-Y')); ?></td>
                    <td class="border px-4 py-3"><?php echo e($anggota->jenis_disabilitas); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($anggotas->isEmpty()): ?>
                <tr>
                    <td colspan="6" class="text-center">Tidak ada data <?php echo e($jenis_disabilitas); ?></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\sistem_disabilitas\resources\views/pdf-dpd.blade.php ENDPATH**/ ?>