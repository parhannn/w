<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Kabupaten;

class KabupatenSeeder extends Seeder
{
    public function run(): void
    {
        Kabupaten::create(['nama' => 'Kabupaten Lampung Selatan']);
        Kabupaten::create(['nama' => 'Kabupaten Lampung Barat']);
        Kabupaten::create(['nama' => 'Kabupaten Lampung Tengah']);
        Kabupaten::create(['nama' => 'Kabupaten Lampung Timur']);
        Kabupaten::create(['nama' => 'Kabupaten Mesuji']);
        Kabupaten::create(['nama' => 'Kabupaten Pringsewu']);
        Kabupaten::create(['nama' => 'Kabupaten Pesisir Barat']);
        Kabupaten::create(['nama' => 'Kabupaten Tanggamus']);
        Kabupaten::create(['nama' => 'Kabupaten Tulang Bawang']);
        Kabupaten::create(['nama' => 'Kabupaten Tulang Bawang Barat']);
        Kabupaten::create(['nama' => 'Kabupaten Way Kanan']);
        Kabupaten::create(['nama' => 'Kabupaten Bandar Lampung']);
        Kabupaten::create(['nama' => 'Kabupaten Metro']);
        Kabupaten::create(['nama' => 'Kabupaten Pesawaran']);
        Kabupaten::create(['nama' => 'Kabupaten Lampung Utara']);
    }
}
