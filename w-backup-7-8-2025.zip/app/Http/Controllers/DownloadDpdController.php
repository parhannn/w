<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Anggota;
use App\Models\Kabupaten;
use App\Models\Kecamatan;
use Barryvdh\DomPDF\Facade\Pdf;

class DownloadDpdController extends Controller
{
    public function index(Request $request)
    {
        $user = Auth::user();

        return view('downloaddpd');
    }
}